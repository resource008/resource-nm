<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

<?php
include ('header.php');
?>
    <main>
        Ini adalah halaman informasi tentang PABI
    </main>
    
<?php
include ('footer.php');
?>
