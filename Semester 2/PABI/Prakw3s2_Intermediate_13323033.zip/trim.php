<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

<?php
    $nama = " andi     ";
    $trim_nama = trim($nama);
    echo $trim_nama; // "andi"
?>