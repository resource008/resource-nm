<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

    <footer>
        &copy; PABI for Fun

        <?php
        echo date ('M-Y')
        ?>

    </footer>
</body>
</html>
