<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initialscale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <h1> PABI itu Mudah </h1>
    </header>
    <nav>
        <li><a href ="index.php"> Home </a></li>
        <li><a href ="tentang.php"> Tentang </a></li>
        <li><a href ="kontak.php"> Kontak </a></li>
    </nav>
    <main>
        Ini adalah halaman informasi tentang PABI
    </main>
    <footer>
        &copy; PABI for Fun 2022
    </footer>
</body>
</html>