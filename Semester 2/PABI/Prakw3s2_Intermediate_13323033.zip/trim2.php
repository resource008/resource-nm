<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

<?php
    $nama = " andi ";
    $nama_juga = " andi";
    if ($nama == $nama_juga) {
        echo "Nama Sama";
    }
    else {
        echo "Nama Beda";
    }
    // hasil: Nama Beda
?>