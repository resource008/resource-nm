<!--
Nama    : Agus Pranata Marpaung
NIM     : 13323033
Kelas   : 31TK2
-->

<?php
require ('header.php');
?>

<?php
require ('header.php');
?>

    <main>
        Selamat datang di mata kuliah PABI, tempat belajar PABI yang happy
    </main>
<?php
require ('footer.php');
?>