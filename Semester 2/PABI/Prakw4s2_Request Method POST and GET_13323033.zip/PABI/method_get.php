<!--
    Nama    : Agus Pranata Marpaung
    NIM     : 13323033
    Kelas   : 31TK2
-->

<?php
echo $_GET['nama'];
echo $_GET['password'];
?>

<form action = "3.method_get.php" method="get">
    <input type = "text" name="nama">
    <input type = "password" name="password">
    <input type = "submit" name="submit">
</form>