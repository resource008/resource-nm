<!--
    Nama    : Agus Pranata Marpaung
    NIM     : 13323033
    Kelas   : 31TK2
-->

<?php
$username = "Anya_Forger";
$password = "telepathy";
if(isset($_POST['submit']))
{
    if($_POST['nama'] == $username && $_POST['password'] == $password)
    {
        header('Location: profile.php?nama=' . $_POST['nama']);
    }else{
        echo 'login gagal';
    }
}
?>

<form action = "login_2.php" method = "post">
    <input type = "text" name = "nama">
    <input type = "password" name = "password">
    <input type = "submit" name = "submit">
</form>