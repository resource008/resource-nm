<!--
    Nama    : Agus Pranata Marpaung
    NIM     : 13323033
    Kelas   : 31TK2
-->

<?php
echo 'ini halaman profile' . " " . $_GET['nama'];
?>