<!--
    Nama    : Agus Pranata Marpaung
    NIM     : 13323033
    Kelas   : 31TK2
-->

<?php
if(isset($_POST['submit']))
{
    echo $_POST['nama'] . '<br>';
    echo $_POST['password'] . '<br>';
}
?>
<form action = "method_post.php" method = "post">
    <input type = "text" name = "nama">
    <input type = "password" name = "password">
    <input type = "submit" name = "submit">
</form>