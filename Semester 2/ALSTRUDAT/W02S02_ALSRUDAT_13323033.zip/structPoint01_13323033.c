/*
    NIM             : 13323033
    Nama            : Agus Pranata Marpaung
    Nama Program    : Struct Point (Cara I – Tanpa Typedef)
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct _point{
    float X; /* absis */
    float Y; /* ordinat */
};

//Fungsi untuk set nilai X dan nilai Y ke dalam struct _point
struct _point MakePOINT (float X, float Y){
    struct _point P;
    P.X=X;
    P.Y=Y;
    return P;
}

//Fungsi untuk meminta Inputan nilai X dan Y dari user
void BacaPOINT (struct _point *P){
    float X,Y;
    scanf("%f %f", &X, &Y);
    *P = MakePOINT(X,Y);
}

//Fungsi untuk menuliskan nilai X dan nilai Y dari struct _point
void TulisPOINT (struct _point P){
    printf(" (%.2f, %.2f)", P.X, P.Y);
}

int main(){
    int N;
    float x, y, sudut;
    struct _point P;

    BacaPOINT(&P);
    printf("POINT berada pada titik: ");
    TulisPOINT(P);
    printf("\n");

    return 0;
}