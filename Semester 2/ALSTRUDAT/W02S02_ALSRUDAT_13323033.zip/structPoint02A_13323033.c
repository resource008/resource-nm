/*
    NIM             : 13323033
    Nama            : Agus Pranata Marpaung
    Nama Program    : Struct Point (Cara II – Dengan Typedef)
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct _point{
    float X; /* absis */
    float Y; /* ordinat */
}POINT;

// Fungsi untuk set nilai X dan nilai Y ke dalam struct _point
POINT MakePOINT (float X, float Y){
    POINT P;
    P.X=X;
    P.Y=Y;
    return P;
}

// Fungsi untuk meminta inputan nilai X dan Y dari user
void BacaPOINT (POINT *P){
    float X,Y;
    scanf("%f %f", &X, &Y);
    *P = MakePOINT(X,Y);
}

// Fungsi untuk menuliskan nilai X dan nilai Y dari struct _point
void TulisPOINT (POINT *P){
    printf("(%.2f,%.2f)", P->X, P->Y);
}

int main(){
    int N;
    float x, y, sudut;
    POINT P;

    BacaPOINT(&P);
    printf("POINT berada pada titik: ");
    TulisPOINT(&P);
    printf("\n");

    return 0;
}