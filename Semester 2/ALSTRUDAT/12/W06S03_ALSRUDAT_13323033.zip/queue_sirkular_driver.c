/*
    NIM             : 13323033
    Nama            : Agus Pranata Marpaung
    Nama Program    : queue_sirkular_driver.c
*/
#include "queue_sirkular.h" 
#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, del, i, j, add_choice;
    Queue Q;

    printf("Masukkan Size Queue: ");
    scanf("%d", &n);
    CreateEmpty(&Q, n);

    long *T = (long *)malloc(n * sizeof(long));

    printf("Silahkan Masukkan Nilai Queue dengan Maksimum %d Elemen Dan Tidak Boleh Angka -99\n", n);
    printf("Jika Nilai -99 atau Sudah Melebihi Batas Maksimum Elemen, Maka Nilai Tidak Dimasukkan ke dalam Queue\n");
    printf("Add Nilai Ke Dalam Queue:\n");

    i = 0;
    do {
        scanf("%ld", &T[i]);
        if (T[i] == -99 || i >= n) {
            break;
        } else {
            Add(&Q, T[i]);
            i++;
        }
    } while (1);

    printf("\nIsi Queue: ");
    if (!IsEmpty(Q)) {
        j = Q.Head;
        while (j != Q.Tail) {
            printf("%ld ", Q.T[j]);
            j = (j + 1) % Q.MaxEl;
        }
        printf("%ld\n", Q.T[j]);
    }

    printf("Nilai Header = %ld\n", Q.T[Q.Head]);
    printf("Indeks Header = %d\n", Q.Head);
    printf("Nilai Tail = %ld\n", Q.T[Q.Tail]);
    printf("Indeks Tail = %d\n", Q.Tail);
    printf("Banyak Elemen = %d\n", (Q.Tail - Q.Head + Q.MaxEl) % Q.MaxEl + 1);

    if (IsFull(Q)) {
        printf("Status Queue: Full\n");
    } else if (IsEmpty(Q)) {
        printf("Status Queue: Empty\n");
    } else {
        printf("Status Queue: Not Full & Not Empty\n");
    }

    printf("Masukkan Jumlah Elemen Yang Akan Dihapus (Delete Queue): ");
    scanf("%d", &del);
    printf("Isi Queue: ");
    for (i = 0; i < del; ++i) {
        long X;
        if (!IsEmpty(Q)) {
            Del(&Q, &X);
            printf("%ld ", X);
        }
    }
    printf("\n");

    // Cetak isi Queue setelah penghapusan
    printf("Nilai Header = %ld\n", Q.T[Q.Head]);
    printf("Indeks Header = %d\n", Q.Head);
    printf("Nilai Tail = %ld\n", Q.T[Q.Tail]);
    printf("Indeks Tail = %d\n", Q.Tail);
    printf("Banyak Elemen = %d\n", (Q.Tail - Q.Head + Q.MaxEl) % Q.MaxEl + 1);

    if (IsFull(Q)) {
        printf("Status Queue Sekarang: Full\n");
    } else if (IsEmpty(Q)) {
        printf("Status Queue Sekarang: Empty\n");
    } else {
        printf("Status Queue Sekarang: Not Full & Not Empty\n");
    }

    printf("Apakah Anda Ingin Melakukan Proses Add Queue (1 Yes, 0 No): ");
    scanf("%d", &add_choice);

    if (add_choice) {
        int additional;
        printf("Silahkan Masukkan Nilai Queue dengan Maksimum %d Elemen Lagi Dan Tidak Boleh Angka -99\n", n - (Q.Tail - Q.Head + Q.MaxEl) % Q.MaxEl - 1);
        printf("Jika Nilai -99 atau Sudah Melebihi Batas Maksimum Elemen, Maka Nilai Tidak Dimasukkan ke dalam Queue\n");
        printf("Add Nilai Ke Dalam Queue:\n");

        i = 0;
        do {
            scanf("%ld", &T[i]);
            if (T[i] == -99 || i >= n) {
                break;
            } else {
                Add(&Q, T[i]);
                i++;
            }
        } while (1);

        printf("\nIsi Queue: ");
        if (!IsEmpty(Q)) {
            j = Q.Head;
            while (j != Q.Tail) {
                printf("%ld ", Q.T[j]);
                j = (j + 1) % Q.MaxEl;
            }
            printf("%ld\n", Q.T[j]);
        }

        printf("Nilai Header = %ld\n", Q.T[Q.Head]);
        printf("Indeks Header = %d\n", Q.Head);
        printf("Nilai Tail = %ld\n", Q.T[Q.Tail]);
        printf("Indeks Tail = %d\n", Q.Tail);
        printf("Banyak Elemen = %d\n", (Q.Tail - Q.Head + Q.MaxEl) % Q.MaxEl + 1);

        if (IsFull(Q)) {
            printf("Status Queue Sekarang: Full\n");
        } else if (IsEmpty(Q)) {
            printf("Status Queue Sekarang: Empty\n");
        } else {
            printf("Status Queue Sekarang: Not Full & Not Empty\n");
        }
    }

    return 0;
}
