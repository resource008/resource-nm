/*
    Nama        : Agus Pranata Marpaung
    NIM         : 13323033
    Kelas       : 31TK2
*/

#include <stdlib.h>
#include "queue.h"

/* ****** KREATOR ****** */
void CreateEmpty(Queue *Q, int Max) {
    Q->T = (long *)malloc(Max * sizeof(long));
    if (Q->T != NULL) {
        Q->MaxEl = Max;
        Q->Head = Nil;
        Q->Tail = Nil;
    } else {
        Q->MaxEl = 0;
    }
}

/* ********* DESTRAKTOR ********* */
void DeAlokasi(Queue *Q) {
    free(Q->T);
    Q->MaxEl = 0;
}

/* ********* Predikat Penting ********* */
int IsEmpty(Queue Q) {
    return (Q.Head == Nil && Q.Tail == Nil);
}

int IsFull(Queue Q) {
    return ((Q.Head == 0 && Q.Tail == Q.MaxEl - 1) ||
            (Q.Head == Q.Tail + 1));
}

/* ********* Primitif Add/Delete ********* */
void Add(Queue *Q, long X) {
    if (!IsFull(*Q)) {
        if (IsEmpty(*Q)) {
            Q->Head = 0;
            Q->Tail = 0;
        } else {
            Q->Tail = (Q->Tail + 1) % Q->MaxEl;
        }
        Q->T[Q->Tail] = X;
    }
}

void Del(Queue *Q, long *X) {
    if (!IsEmpty(*Q)) {
        *X = Q->T[Q->Head];
        if (Q->Head == Q->Tail) { /* set to empty */
            Q->Head = Q->Tail = Nil;
        } else {
            Q->Head = (Q->Head + 1) % Q->MaxEl;
        }
    }
}
