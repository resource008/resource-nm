/*
    Nama        : Agus Pranata Marpaung
    NIM         : 13323033
    Kelas       : 31TK2
*/

#include <stdio.h>
#include "queue.h"

int main() {
    Queue Q;
    long X;
    int Max, choice;

    printf("Masukkan ukuran maksimal queue: ");
    scanf("%d", &Max);

    CreateEmpty(&Q, Max);

    do {
        printf("\nQueue Operations\n");
        printf("1. Tambahkan elemen\n");
        printf("2. Hapus elemen\n");
        printf("3. Cek apakah queue kosong\n");
        printf("4. Cek apakah queue penuh\n");
        printf("0. Keluar\n");

        printf("Pilihan: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Masukkan elemen: ");
                scanf("%ld", &X);
                Add(&Q, X);
                break;
            case 2:
                if (!IsEmpty(Q)) {
                    Del(&Q, &X);
                    printf("Elemen yang dihapus: %ld\n", X);
                } else {
                    printf("Queue kosong\n");
                }
                break;
            case 3:
                if (IsEmpty(Q)) {
                    printf("Queue kosong\n");
                } else {
                    printf("Queue tidak kosong\n");
                }
                break;
            case 4:
                if (IsFull(Q)) {
                    printf("Queue penuh\n");
                } else {
                    printf("Queue tidak penuh\n");
                }
                break;
            case 0:
                printf("Keluar\n");
                break;
            default:
                printf("Pilihan tidak valid\n");
        }

    } while (choice != 0);

    DeAlokasi(&Q);

    return 0;
}
