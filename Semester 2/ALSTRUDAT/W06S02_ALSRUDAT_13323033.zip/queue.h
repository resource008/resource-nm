/*
    Nama        : Agus Pranata Marpaung
    NIM         : 13323033
    Kelas       : 31TK2
*/

#ifndef _QUEUE_H
#define _QUEUE_H

#define boolean unsigned char
#define true 1
#define false 0
/* Konstanta */
#define Nil -99
/* Nil adalah indeks tak terdefinisi */

/* Versi I : tabel dinamik, Head dan Tail eksplisit, ukuran disimpan */
typedef struct {
    long * T; /* tabel penyimpan elemen */
    int Head; /* alamat penghapusan */
    int Tail; /* alamat penambahan */
    int MaxEl; /* Max elemen queue */
} Queue;
/* Definisi Queue kosong : HEAD=Nil; TAIL=Nil. */
/* Definisi container tabel Queue dari indeks 0..MaxEl-1 */

/* ********Prototype********** */
/* ****Kreator***** */
void CreateEmpty(Queue *Q, int Max);
/* I.S. sembarang */
/* F.S. Sebuah Q kosong terbentuk dan salah atu kondisi sbb: */
/* Jika alokasi berhasil, tabel memori dialokasi berukuran Max */
/* atau : jika alokasi gagal, Q koong dg MaxEl=0 */
/* Proses : Melakukan alokasi, membuat sebuah Q kosong*/
/* *** Destruktor *** */
void DeAlokasi(Queue *Q);
/* Proses: Mengembalikan memori Q */
/* I.S. Q pernah dialokasi */
/* F.S. Q menjadi tidak terdefinisi lagi, MaxEl(Q) diset 0 */

/* *** Predikat Penting *** */
int IsEmpty(Queue Q);
/* Mengirim true jika Q kosong: lihat definisi di atas */
int IsFull(Queue Q);
/* Mengirim true jika tabel penampung elemen Q sudah penuh */
/* yaitu mengandung elemen sebanyak MaxEl */

/* *** Primitif Add/Delete *** */
void Add(Queue *Q, long X);
/* Proses: Menambahkan X pada Q dengan aturan FIFO */
/* I.S. Q tidak mungkin kosong */
/* F.S. X = nilai elemen HEAD pd I.S.,HEAD "maju"; Q mungkin kosong */
void Del(Queue *Q, long *X);
/* Proses: Menghapus elemen pertama pada Q dengan aturan FIFO */
/* I.S. Q tidak mungkin kosong */
/* F.S. X = nilai elemen HEAD pd I.S., HEAD "maju";
        Q mungkin kosong */
#endif
