// Nama         : Agus Pranata Marpaung
// NIM          : 13323033
// Mata Kuliah  : ALSTRUDAT

#include <stdio.h>
int my_array[] = {1,23,17,4,-5,100};
int *ptr;
int main(void)
{
    int i;
        ptr = &my_array[0]; /* pointer to the first element of the array*/
        for (i = 0; i < 6; i++)
        {
            printf("[%d] = %d\n",i, ptr+i);
        }
        return 0;
}