// Nama         : Agus Pranata Marpaung
// NIM          : 13323033
// Mata Kuliah  : ALSTRUDAT

#include <stdio.h>

int main() {
    int x, y; 
    int *p;
    int *q; 
    x=2, y=7;
    p=&x,q=&y;

    // a) Menampilkan alamat x dan nilai x
    printf("Alamat x adalah: %p, Nilai x adalah: %d\n", &x, x);

    // b) Menampilkan nilai p dan nilai *p
    printf("Nilai p adalah: %p, Nilai *p adalah: %d\n", p, *p);

    // c) Menampilkan alamat y dan nilai y
    printf("Alamat y adalah: %p, Nilai y adalah: %d\n", &y, y);

    // d) Menampilkan nilai q dan nilai *q
    printf("Nilai q adalah: %p, Nilai *q adalah: %d\n", q, *q);

    return 0;
}