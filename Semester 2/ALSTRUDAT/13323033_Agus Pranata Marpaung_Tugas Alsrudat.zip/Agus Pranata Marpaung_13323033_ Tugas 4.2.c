// Nama         : Agus Pranata Marpaung
// NIM          : 13323033
// Mata Kuliah  : ALSTRUDAT

#include <stdio.h>
int main(void)
{
    char ch = 'c';
    char *chptr = &ch;
    int i = 20;
    int *intptr = &i;
    float f = 1.20000;
    float *fptr = &f;
    char *strPtr = " I am a string";
    printf ("\n [%c], [%d], [%f], [%c], [%d]\n", *chptr, *intptr, *fptr, *strPtr, strPtr);

    return 0;
}