<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <title>PHP itu Mudah</title> 
</head> 
<body> 
<?php 
  // Ini adalah syntax komentar untuk satu baris 
  echo "<h1>Hallo </h1>"; 
  echo "Namaku <br>"; 

  /* 
  Ini adalah syntax komentar untuk beberapa baris 
  */ 
  echo "Jiemi Ardian"; 
?> 
Hallo Semuanya!!! 
</body> 
</html>
