<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PHP itu Mudah</title>
</head>
<body>
<?php
// Variabel pada PHP
  $nama = "belajar PABI";
  $nama2 = "sambil mendengar lagu";
  $num1 = 1000;
  $num2 = 900;

// Akses nilai pada variabel
  echo "Selamat datang di $nama <br>";
  echo $num1 . $num2 . "<br>";

// Variabel dengan tipe data integer
  $angka = 100;

// Variabel dengan tipe float
  $angka2 = 20.50;
  $angka3 = 5;
  $angka4 = 8;

/* Pemberian nilai dari sebuah variabel dapat dioperasikan dengan nilai sebelumnya
   Dioperasikan dengan nilai variabel lain
   Sesuaikan hasil/output dengan urutan operasi matematika ketika SD
*/
  $hasil = $angka + $angka2 * $angka3 / $angka4 - $angka3;

// Penulisan $angka = $angka + $angka3; dapat disingkat
  $angka *= $angka3;
  echo $hasil . "<br>";
  echo $angka . "<br>";

// Operator increment
  $angka++;
  echo $angka . "<br>";

// Operator decrement
  $angka--;
  echo $angka . "<br>";
?>
</body>
</html>
