<?php
// Class manusia
class Manusia {
    // Property
    public $nama;
    public $warna;

    // Method
    public function tampilkan_nama() {
        return "Nama saya Rivaldo Tampan <br/>";
    }

    public function warna_kulit() {
        return "Warna kulit saya hitam <br/>";
    }
}

// Instansiasi class Manusia
$manusia = new Manusia();

// Memanggil method tampilkan_nama dari class Manusia
echo $manusia->tampilkan_nama();

// Memanggil method warna_kulit dari class Manusia
echo $manusia->warna_kulit();
?>
