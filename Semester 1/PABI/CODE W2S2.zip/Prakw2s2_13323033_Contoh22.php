<?php
    $showRoom = array("Volvo", "BMW", "Toyota");
    var_dump($showRoom);
?>
