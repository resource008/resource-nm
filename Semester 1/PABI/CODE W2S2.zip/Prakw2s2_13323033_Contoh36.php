<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Belajar PHP</title> 
</head> 
<body> 
    <?php 
    // Variabel pada PHP 
    $nama = "Multi Dimensi Array"; 
 
    // Akses nilai pada variabel 
    echo "Selamat datang di $nama <br>"; 
 
    // Multi Dimensi Array 
    $data = [
        "nama" => "Aku anak baik", 
        "umur" => 18, 
        "sifat" => "Semangat belajar, supaya boleh membanggakan orang yang ku sayangi"
    ]; 
 
    // Print keseluruhan nilai dari array 
    foreach ($data as $key => $value) { 
        echo $key . " : " . $value . "<br>"; 
    } 
    ?> 
</body> 
</html>
