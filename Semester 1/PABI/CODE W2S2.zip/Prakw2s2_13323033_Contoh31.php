<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Belajar PHP</title> 
</head> 
<body> 
    <?php 
    // Variabel pada PHP 
    $nama = "Multi Dimensi Array"; 
 
    // Akses nilai pada variabel 
    echo "Selamat datang di $nama <br>";  
 
    // Multi Dimensi Array
    $data = array(
        array("Programmer", 21, "ngopi"), 
        array("kuli bangunan", 48, "berenang"), 
        array("Mahasiswa", 20, "tidur siang")
    ); 
 
    // Menampilkan nilai dari seluruh array 
    print_r($data); 
    echo "<br>"; 
 
    // Menampilkan nilai dari index array 
    echo $data[1][1]; 
    echo "<br>"; 
 
    // Update nilai dari index array 
    $data[0][0] = "Pemain bola"; 
    echo $data[0][0]; 
    echo "<br>"; 
    ?> 
</body> 
</html> 
