<?php 
$x = 0;  
while ($x <= 100) { 
    echo "Angka Sekarang: $x <br>"; 
    $x += 10; 
} 
?> 
