<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PHP itu Mudah</title>
</head>
<body>
  <?php
  echo "<h1>Hallo</h1>";
  echo "<p>Namaku <br> Jiemi Ardian</p>"; // Tambahkan spasi setelah <br>
  ?>
  <p>Hallo Semuanya!!!</p>
</body>
</html>
