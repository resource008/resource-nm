<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Belajar PHP</title> 
</head> 
<body> 
    <?php 
    // Variabel pada PHP 
    $nama = "Multi Dimensi Array"; 
 
    // Akses nilai pada variabel 
    echo "Selamat datang di $nama <br>"; 
 
    // Single Dimensi Array 
    $mahasiswa = ['Thalia','Daniel', 'Rico', 'Cindy', 'Barney']; 
 
    // Print keseluruhan nilai dari array 
    foreach ($mahasiswa as $x) { 
        echo $x . "<br>"; 
    } 
    ?> 
</body> 
</html> 
