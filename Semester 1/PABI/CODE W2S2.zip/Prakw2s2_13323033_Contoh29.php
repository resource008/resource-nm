<?php 
// Cara pertama membuat associative array.
$mahasiswa_satu = array(
    "Matematika" => 95,
    "Fisika" => 90,
    "PABI" => 96,
    "English" => 93,
    "Sisop" => 98
);

// Cara kedua membuat associative array.
    $mahasiswa_dua["Matematika"] = 95;
    $mahasiswa_dua["Fisika"] = 90;
    $mahasiswa_dua["PABI"] = 96;
    $mahasiswa_dua["English"] = 93;
    $mahasiswa_dua["Sisop"] = 98;
 
// Akses elemen array langsung.
    echo "Marks for mahasiswa satu is:\n"; 
    echo "Matematika:" . $mahasiswa_satu["Matematika"], "\n"; 
    echo "Fisika:" . $mahasiswa_satu["Fisika"], "\n"; 
    echo "PABI:" . $mahasiswa_satu["PABI"], "\n"; 
    echo "English:" . $mahasiswa_satu["English"], "\n"; 
    echo "Sisop:" . $mahasiswa_satu["Sisop"], "\n"; 
?>
