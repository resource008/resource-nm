<?php 
$x = "Hello world!"; 
$y = 'Hello world!'; 

// Menampilkan nilai dari variabel x dan y
echo $x; 
echo "<br>"; 
echo $y; 
?> 
