<!DOCTYPE html> 
<html lang="en"> 
<head> 
  <meta charset="UTF-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <title>PHP itu Mudah</title> 
</head> 
<body> 
<?php 
  // Variabel pada PHP 
  $nama = "belajar PABI"; 
  $nama2 = "sambil mendengar lagu"; 
 
  // Akses nilai pada variabel 
  echo $nama . "<br>"; 
 
  // Cara menggabungkan nilai dari kedua variabel 
  echo $nama . " " . $nama2 . "<br>"; 
  echo $nama . " untuk " . $nama2; 
?> 
</body> 
</html>
