<?php 
$x = 1;  
do { 
    echo "Angka sekarang adalah: $x <br>"; 
    $x++; 
} while ($x <= 5); 
?>
