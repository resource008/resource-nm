<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Belajar PHP</title> 
</head> 
<body> 
    <?php 
    // Variabel pada PHP 
    $nama = "Belajar PABI"; 
 
    // Akses nilai pada variabel 
    echo "Selamat datang di $nama <br>"; 
 
    // Tipe data Array   	 
    $sifat = array('baik semangat ya', 'perhatian', 'cuek', 'lemah lembut'); 
    $nama = ['Jiemi Ardian Tampan', 'Bien', 'anak baik']; 
    print_r($nama); 
    echo "<br>"; 
    print_r($nama[2]); 
    echo "<br>"; 
    echo "Hai" . " " . $nama[1] . " " . $sifat[0]; 
    ?> 
</body> 
</html> 
