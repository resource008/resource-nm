<?php 
  $age = array("Jackob" => "25", "Bien" => "27", "Putri" => "13"); 
  foreach ($age as $x => $val) { 
  echo "$x = $val<br>"; 
} 
?> 
