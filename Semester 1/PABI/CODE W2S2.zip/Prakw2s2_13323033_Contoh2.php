<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>PHP itu Mudah</title> 
</head> 
<body> 
<?php 
    $hewan = ['buaya', 'anjing', 'babi', 'cicak', 'domba']; 
    $i = 0; 
    while ($i < count($hewan)) {        
    echo $hewan[$i] . "<br>"; 
    $i++; 
} 
?> 
</body> 
</html>