<?php 
 
$umur=20; 
 
if ($umur > 18){ 
 
 	echo  "Kamu sudah dewasa <br>";  
    echo "Tapi masih saja malas";  
    echo "<br> Jangan gitu lagi ya, ada orang yang harus kamu banggakan"; 
} 
 	 
?> 
