/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Membuat program ganjil genap
Tanggal     : 19/09/2023
*/

#include <stdio.h>

int main()
{
    //Kamus
    int x;
    char line[256];
    
    //algoritma:
    printf("Masukan sebuah bilangan bulat: ");
    if (fgets(line, sizeof(line), stdin)) {
        sscanf(line, "%d", &x);
        if (x % 2 == 0)
            printf("%d bilangan genap\n", x);
        else
            printf("%d bilangan ganjil\n", x);
    }

    return 0;
}