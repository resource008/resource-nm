/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Membuat program menghitung peringkat_kredit
Tanggal     : 25/09/2023
*/

#include <stdio.h>

int main() {
    int pokok_utang, masa_tunggak;

    //Hasil
    printf("Masukkan pokok utang: ");
    scanf("%d", &pokok_utang);

    printf("Masukkan masa tunggak: ");
    scanf("%d", &masa_tunggak);

    //Algoritma
    if (pokok_utang < 100000000) {
        if (masa_tunggak < 6) {
            printf("Peringkat Utang anda di Jadwalkan\n");
        } else {
            printf("Peringkat utang anda di Gagalkan\n");
        }
    } else {
        if (masa_tunggak < 12) {
            printf("Peringkat Utang anda di Jadwalkan\n");
        } else {
            printf("Peringkat utang anda di Gagalkan\n");
        }
    }

    return 0;
}
