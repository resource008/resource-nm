/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Membuat program grade_mod
Tanggal     : 19/09/2023
*/

#include <stdio.h>

int main()
{
    //kamus:
    float x;
    char line[256], ch;

    //Algoritma:
    printf("Masukkan nilai kuliah anda: ");
    if (fgets(line, sizeof(line), stdin)) {
        sscanf(line, "%f", &x);
        if (x > 80) 
            ch = 'A';
        else if (x >= 65) 
            ch = 'B';
        else if (x >= 50) 
            ch = 'C';
        else if (x >= 35) 
            ch = 'D';
        else 
            ch = 'E';
        printf("Anda mendapatkan grade %c\n", ch);
    }

    return 0;
}
