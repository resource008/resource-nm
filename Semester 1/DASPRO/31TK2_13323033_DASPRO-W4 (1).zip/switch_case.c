/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Percabangan di Bahasa C (Praktikum II, 2)
Tanggal     : 25/09/2023
*/

#include<stdio.h>

int main ()
{
int x;
int y;
int z;
char operasi;

printf("masukan operasi aritmatika(+,-,x,/): ");
scanf("%c", &operasi);

switch (operasi)
{
case '+':
    printf("masukan 2 bilangan bulat\n");
    scanf("%d %d", &x,&y);
    printf("x= %d\t y=%d\n\n", x,y);
    z= x+y;
    printf("x+y = %d\n", z);
    break;
case '-':
    printf("masukan 2 bilangan bulat\n");
    scanf("%d %d", &x,&y);
    printf("x= %d\t y=%d\n\n", x,y);
    z= x-y;
    printf("x-y = %d\n", z);
    break;
case 'x':
    printf("masukan 2 bilangan bulat\n");
    scanf("%d %d", &x,&y);
    printf("x= %d\t y=%d\n\n", x,y);
    z= x*y;
    printf("x*y = %d\n", z);
    break;  
case '/':
    printf("masukan 2 bilangan bulat\n");
    scanf("%d %d", &x,&y);
    printf("x= %d\t y=%d\n\n", x,y);
    z= x/y;
    printf("x/y = %d\n", z);
    break;
}
}