/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Percabangan di Bahasa C(Praktikum II,1)
Tanggal     : 25/09/2023
*/

#include<stdio.h>
#include<stdbool.h>
#include<stdlib.h>

int main (int argc, char *argv[])
{
    int umur;
    float gaji;
    bool statusApl = false;
    umur = atoi(argv[1]);
    gaji = atoi(argv[2]);
    printf("umur Anda: %d\n", umur);

    printf("gaji Anda: %.2f\n", gaji);

    if(umur>60){
        statusApl = false;
        printf("Aplikasi Anda ditolak!\n");
    }
    else if(gaji<3000000){
        statusApl = false;
        printf("Aplikasi Anda ditolak!\n");
    }
    else{
        statusApl = true;
        printf("aplikasi Anda diterima!\n");
    }

return 0;
}





