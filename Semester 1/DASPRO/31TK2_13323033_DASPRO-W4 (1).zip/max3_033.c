/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Menentukan bilangan maksimum dari tiga buah bilangan dan mencetak yang terbesar
Tanggal     : 21/09/2023
*/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        printf("Usage: %s <number1> <number2> <number3>\n", argv[0]);
        return 1;
    }

    int num1 = atoi(argv[1]);
    int num2 = atoi(argv[2]);
    int num3 = atoi(argv[3]);

    int max = num1;

    if (num2 > max) {
        max = num2;
    }

    if (num3 > max) {
        max = num3;
    }

    printf("Bilangan terbesar adalah: %d\n", max);

    return 0;
}
