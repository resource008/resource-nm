/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Percabangan di Bahasa C (Praktikum I, 1)
Tanggal     : 25/09/2023
*/

#include <stdio.h>
int main()
{
    //Kamus
    int x;
    //algoritma:
    printf("Masukkan sebuah bilangan bulat: ");
    scanf("%d", &x);
    if (x%2==0)
        printf("%d bilangan genap\n", x);
    else
        printf("%d bilangan ganjil\n", x);
    return 0;
}