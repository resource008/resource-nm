/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Membuat program wujud air
Tanggal     : 21/09/2023
*/

#include <stdio.h>

int main()
{
    //kamus:
    float x;
    char *ch;
    //Algoritma:
    printf("Masukkan nilai suhu untuk menentukan wujud air: ");
    scanf("%f", &x);
    if (x<0) ch = "Padat";
    else if (x>=100) ch = "Gas";
    else if (0<=x && x<100) ch = "Cair";
    printf("Wujud air tersebut adalah %s\n", ch);

    return 0;
}