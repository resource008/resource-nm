//Nama Saya  : Agus Pranata Marpaung
//NIM Saya   : 13323033
//Prodi Saya : D3 Teknologi Komputer
//Program    : 5

#include <stdio.h>
#include <math.h>

void printInfo() {
    printf("Nama Saya *Agus Pranata Marpaung*\n");
    printf("NIM Saya adalah *13323033*\n");
    printf("Prodi Saya *D3 Teknologi Komputer*\n");
    printf("Ini adalah program no 3\n");
}

void printPattern(int n) {
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            if(j <= n - i + 1) {
                printf("* ");
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
}

int main() {
    int n = 5;
    printPattern(n);
    return 0;
}