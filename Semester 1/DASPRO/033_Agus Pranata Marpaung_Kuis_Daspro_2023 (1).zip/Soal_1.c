//Nama Saya  : Agus Pranata Marpaung
//NIM Saya   : 13323033
//Prodi Saya : D3 Teknologi Komputer
//Program    : 1

#include <stdio.h>

void printInfo() {
    printf("Nama Saya *Agus Pranata Marpaung*\n");
    printf("NIM Saya adalah *13323033*\n");
    printf("Prodi Saya *D3 Teknologi Komputer*\n");
    printf("Ini adalah program no 1\n");
}

void sortNumbers() {
    int bilangan[5], i, j, temp;

    printf("Masukkan 5 bilangan:\n");
    for(i = 0; i < 5; i++) {
        scanf("%d", &bilangan[i]);
    }

    for(i = 0; i < 5; i++) {
        for(j = i+1; j < 5; j++) {
            if(bilangan[i] < bilangan[j]) {
                temp = bilangan[i];
                bilangan[i] = bilangan[j];
                bilangan[j] = temp;
            }
        }
    }

    printf("Bilangan dalam urutan Descending:\n");
    for(i = 0; i < 5; i++) {
        printf("%d\n", bilangan[i]);
    }
}

int main() {
    printInfo();
    sortNumbers();
    
    return 0;
}
