//Nama Saya  : Agus Pranata Marpaung
//NIM Saya   : 13323033
//Prodi Saya : D3 Teknologi Komputer
//Program    : 2

#include <stdio.h>
#include <math.h>

void printInfo() {
    printf("Nama Saya *Agus Pranata Marpaung*\n");
    printf("NIM Saya adalah *13323033*\n");
    printf("Prodi Saya *D3 Teknologi Komputer*\n");
    printf("Ini adalah program no 2\n");
}

int main() {
    printInfo();
    int n;
    printf("Input: ");
    scanf("%d", &n);
    printf("Output: ");
    for(int i = 0; i < n; i++) {
        printf("%d ", (int)pow(3, i));
    }
    return 0;
}