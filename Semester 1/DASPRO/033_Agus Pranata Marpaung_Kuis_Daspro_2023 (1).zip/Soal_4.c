//Nama Saya  : Agus Pranata Marpaung
//NIM Saya   : 13323033
//Prodi Saya : D3 Teknologi Komputer
//Program    : 4

#include <stdio.h>
#include <math.h>

void printInfo() {
    printf("Nama Saya *Agus Pranata Marpaung*\n");
    printf("NIM Saya adalah *13323033*\n");
    printf("Prodi Saya *D3 Teknologi Komputer*\n");
    printf("Ini adalah program no 3\n");
}

int main() {
    int n = 10;
    int i, val = 1;

    for(i = 1; i <= n; i++) {
        printf("%d ", val);
        if(i % 2 != 0) {
            val = val + (i * 5);
        } else {
            val = val * 2;
        }
    }

    return 0;
}

