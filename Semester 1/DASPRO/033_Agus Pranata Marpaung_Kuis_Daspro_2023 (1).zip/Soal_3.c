//Nama Saya  : Agus Pranata Marpaung
//NIM Saya   : 13323033
//Prodi Saya : D3 Teknologi Komputer
//Program    : 3

#include <stdio.h>
#include <math.h>

void printInfo() {
    printf("Nama Saya *Agus Pranata Marpaung*\n");
    printf("NIM Saya adalah *13323033*\n");
    printf("Prodi Saya *D3 Teknologi Komputer*\n");
    printf("Ini adalah program no 3\n");
}

int main() {
    int n;
    printf("Input: ");
    scanf("%d", &n);

    int arr[n];
    arr[0] = 1;
    arr[1] = 1;

    for (int i = 2; i < n; i++) {
        if (i % 2 == 0)
            arr[i] = arr[i-2] + i/2;
        else
            arr[i] = arr[i-2] * 2;
    }

    printf("Output: ");
    for (int i = 0; i < n; i++) {
        printf("%d", arr[i]);
        if (i != n - 1)
            printf(", ");
    }

    return 0;
}

