//Nama : Agus Pranata Marpaung
//NIM : 13323033
//Kelas : 31TK2

#include <stdio.h>
int factorial(int _x);
int main(void){
    int z = 4;
    int result = factorial(z);
    printf("%d! is %d\n", z, result);
}

int factorial(int _z);
    if( _z == 1) return(1); //What would happen if this line is delected?
    return( _z*factorial( _z-1));