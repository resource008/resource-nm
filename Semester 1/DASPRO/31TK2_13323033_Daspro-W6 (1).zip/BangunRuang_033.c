//Nama      : Agus Pranata Marpaung
//NIM       : 13323033
//Kelas     : 31TK2

#include <stdio.h>
#include <stdlib.h>

void ulangi();

int main()
{
    int bidang, s, P, L, A, T, R, t, V, W, X, Y, Z, J, K, M, N;
    float a, b, c, v, w, x, y, z, PI=3.14;

//Membuat menu pada bangun ruang
    printf("===Menghitung Keliling dan Luas Bidang Ruang==\n");
    printf("1. Kubus\n");
    printf("2. Balok\n");
    printf("3. Limas\n");
    printf("4. Prisma\n");
    printf("5. Tabung\n");
    printf("6. Kerucut\n");
    printf("7. Bola\n");
    scanf("%d", &bidang);

    switch (bidang) //Membuat rumus dan nampilkan hasil pada bangun ruang
    {
    case 1:
        printf("Kubus\n");
        printf("Masukkan nilai S: ");
        scanf("%d", &s);
        a = 6 * (s * s);
        v = 12 * s;
        printf("Luas Kubus: %.f\n", a);
        printf("Keliling Kubus =%.f\n", v); 
        ulangi();
        break;

    case 2:
        printf("Balok\n");
        printf("Masukkan Nilai Panjang =");
        scanf("%d", &P);
        printf("Masukkan Nilai Lebar =");
        scanf("%d", &L);
        printf("Masukkan Nilai Tinggi =");
        scanf("%d", &t);
        b = 2 * (P * L) + (P * t) + (L * t);
        w = 4 * (P + L + t);
        printf("Luas Balok: %.f\n", b);
        printf("Keliling Balok = %.f\n", w);
        ulangi();
        break;

    case 3:
        printf("Limas\n");
        printf("Masukkan Nilai sisi:");
        scanf("%d", &A);
        printf("Masukkan Nilai Panjang Rusuk:");
        scanf("%d", &T);
        c = (A * A) + (4 * A);
        x = 4 * A + T;
        printf("Luas Segitiga: %.f\n", c);
        ulangi();
        break;

    case 4:
        float d;
        printf("Prisma\n");
        printf("Masukkan Nilai Tinggi =");
        scanf("%d", &R);
        printf("Masukkan Nilai Alas =");
        scanf("%d", &X);
        printf("Masukkan Nilai Sisi =");
        scanf("%d", &W);
        d = R * W * (X * W + (3 * R));
        y = 3 * W;
        printf("Luas Prisma = %.f\n", d);
        printf("Keliling Prisma = %.f\n", y);
        ulangi();
        break;

    case 5:
        float e;
        printf("Tabung\n");
        printf("Masukkan Nilai Tinggi Tabung =");
        scanf("%d", &X);
        printf("Masukkan Nilai Jari-Jari = ");
        scanf("%d", &Z);
        e = PI * (z*Z);
        z = 2 * PI * Z;
        printf("Luas Tabung Adalah = %.f\n", e);
        printf("Keliling Tabung Adalah =%.f\n", z);
        ulangi();
        break;

    case 6:
        float F, G;
        printf("Kerucut\n");
        printf("Masukkan Nilai Jari-Jari = ");
        scanf("%d",&J);
        printf("Masukkan Nilai Garis Pelukis Kerucut =");
        scanf("%d",&K);
        printf("Masukkan Nilai Tinggi =");
        scanf("%d", &L);
        F = PI * J * (K + J);
        G = 0.33 * PI * J * J * L;
        printf("Luas Kerucut Adalah = %.2f\n", F);
        printf("Keliling Kerucut Adalah = %.2f\n", G);
        ulangi();
        break;
    
    case 7:
        float j, k;
        printf("Masukkan Nilai Jari-Jari =");
        scanf("%d",&M);
        j = 4 * PI * M * M;
        k = 1.33 * PI * M * M;
        printf("Luas Bola Adalah = %.2f\n", j);
        printf("Keliling Bola Adalah = %.2f\n", k);
        ulangi();
        break;

    default:
        printf("Maaf, Format nilai tidak sesuai\n");
        break;
    }

    return 0;
}

//Memberi pemberitahuan kepada user dan input jawabannya
void ulangi()
{
    char jawaban;
    printf("Apakah Anda ingin menghitung keliling dan luas bidang ruang kembali (M/m) atau mengakhiri program (E/e)? ");
    scanf(" %c", &jawaban);

    if (jawaban == 'M' || jawaban == 'm')
    {
        system("cls");
        main();
    }
    else if (jawaban == 'E' || jawaban == 'e')
    {
        exit(0);
    }
    else
    {
        printf("Jawaban tidak valid. Silakan coba lagi.\n");
        ulangi();
    }
}
