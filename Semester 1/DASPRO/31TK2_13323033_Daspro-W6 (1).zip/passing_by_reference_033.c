//Nama : Agus Pranata Marpaung
//NIM : 13323033
//Kelas : 31TK2

#include <stdio.h>

void passByValue(int x);
void passByReference(int *x);

int main(int argc, char **argv){
    int x = 1;
    passByValue(x);
    printf("X is %d\n", x);
    passByReference(&x);
    printf("X is %d\n", x);
}

void passByValue(int x){
    x += x;
    printf("Val: \nX is %d\n", x);
}

void passByReference(int *x){
    *x += *x;
    printf("\nRef: \nX is %d\n", *x);
}