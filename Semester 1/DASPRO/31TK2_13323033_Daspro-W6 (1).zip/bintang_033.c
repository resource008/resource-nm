//Nama : Agus Pranata Marpaung
//NIM : 13323033
//Kelas : 31TK2

#include <stdio.h>

int main() {
    int baris, bintang;

    printf("Masukkan jumlah baris: ");
    scanf("%d", &baris);

    printf("Masukkan jumlah bintang: ");
    scanf("%d", &bintang);

    for(int i = 0; i < baris; i++) {
        for(int j = 0; j < bintang; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
