//Nama: Agus Pranata Marpaung
//Prodi: D3TK
//Tentang: Tugas Praktikum DASPRO #1

//Library
#include <stdio.h>

//Kode
int main() {
    int angka1, angka2, hasilBagi, sisaPembagian;

    printf("Masukkan angka pertama: ");
    scanf("%d", &angka1);

    printf("Masukkan angka kedua: ");
    scanf("%d", &angka2);

    hasilBagi = angka1 / angka2;
    sisaPembagian = angka1 % angka2;

    printf("Hasil pembagian: %d\n", hasilBagi);
    printf("Sisa pembagian: %d\n", sisaPembagian);

    return 0;
}
