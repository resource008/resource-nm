//Nama: Agus Pranata Marpaung
//Prodi: D3TK
//Tentang: Tugas Praktikum DASPRO #4

//Library
#include <stdio.h>

//Kode
int main() {
    int a = 2;  
    int d = 3; 
    int n = 20; 

    int Un = a + (n - 1) * d; // Rumus deret aritmatika

    printf("Suku ke-%d dari deret bilangan adalah: %d\n", n, Un);

    return 0;
}
