//Nama: Agus Pranata Marpaung
//Prodi: D3TK
//Tentang: Tugas Praktikum DASPRO #3

//Library
#include <stdio.h>

int main() {
    // Persamaan: 639cd + 4 = 1251
    // Kita ingin mencari nilai cd.

    // Kita mulai dengan mengurangkan 4 dari kedua sisi persamaan.
    // Ini akan menghasilkan 639cd = 1251 - 4 = 1247.
    // Selanjutnya, kita akan membagi kedua sisi dengan 639 untuk mendapatkan nilai cd.

    // Variabel untuk menyimpan nilai cd
    double cd;
    cd = (1251.0 - 4.0) / 639.0;

    // Hasilnya
    printf("Nilai cd adalah: %.2lf\n", cd);

    return 0;
}
