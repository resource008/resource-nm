//Nama: Agus Pranata Marpaung
//Prodi: D3TK
//Tentang: Tugas Praktikum DASPRO #2

//Library
#include <stdio.h>

//Kode
int main() {
    int sabun = 2, shampo = 2, sabunWajah = 2;
    int hargaSabun = 8000, hargaShampo = 35000, hargaSabunWajah = 39000;
    int uangPakPurwa = 310000;
    int totalPembelian, sisaUang;

    totalPembelian = (sabun * hargaSabun) + (shampo * hargaShampo) + (sabunWajah * hargaSabunWajah);
    sisaUang = uangPakPurwa - totalPembelian;

    printf("Total pembelian: Rp %d\n", totalPembelian);
    printf("Sisa uang Pak Purwa: Rp %d\n", sisaUang);

    return 0;
}
