#include <stdio.h>
#include <stdlib.h>

int main() {
    int data[] = {2534, 4652, 8476, 2341, 4876};
    int i, n = sizeof(data) / sizeof(data[0]);

    for (i = 0; i < n; i++) {
        printf("Data %d berada di alamat memori %p\n", data[i], &data[i]);
    }

    return 0;
}