#include <stdio.h>

//Deklarasi dan sekaligus inisialisasi variabel tipe integer
int a_var = 10;

//Deklarasi variabel pointer ke variabel tipe integer
int *a_ptr;

int main()
{
    //Inisialisasi nilai pointer merujuk ke alamat a_var
    a_ptr = &a_var; //Simbol "&" dibaca address of (alamat dari)

    //Akses dan tampilkan alamat memori yang ditunjuk pointer
    printf("\nAlamat memori ditunjuk *a_ptr = %d", a_ptr);
    printf("\nAlamat memori variabel *a_ptr = %d\n", &a_var);


    //Akses dan tampilka nilai variabel: a_var
    printf("\nAkses langsung (a_var)            : a_var = %d", a_var);
    printf("\nAkses tak langsung (*a_ptr)       : a_var = %d\n", *a_ptr);
}