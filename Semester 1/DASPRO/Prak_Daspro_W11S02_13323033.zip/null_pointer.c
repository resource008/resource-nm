#include <stdio.h>

int main(void) {
    int num = 10;
    int *ptr = &num;

    //We can also check with 0 instead of NULL
    if(ptr == NULL)
        printf("ptr: NULL\n");
    else
        printf("ptr: NOT NULL\n");

    //Assigning 0
    ptr = 0;
    if(ptr == NULL)
        printf("ptr: NULL\n");
    else
        printf("ptr: NOT NULL \n");

    return 0;
}