// Nama: Agus Pranata Marpaung
// NIM: 13323033
// Kelas: 31TK2

#include <stdio.h>
int main()
{
    char word1[30]; 
    char word2[30]; 
	char word3[30];

    printf("Enter Word 1: ");
    scanf("%s", word1); 

    printf("Enter Word2: ");
    scanf("%s", word2); 
	
	printf("Enter Word 3: ");
    scanf("%s", word3); 

    printf("Word 1 adalah: %s, Word 2 adalah: %s, Word 3 adalah: %s", word3, word2, word1);

    return 0;
}
