// Nama: Agus Pranata Marpaung
// NIM: 13323033
// Kelas: 31TK2
#include <stdio.h>
#include <ctype.h> 

int main()
{
    char hobby1[30];
    char hobby2[30];
    char hobby3[30];

    printf("Enter Hobby 1: ");
    scanf("%s", hobby1);

    printf("Enter Hobby 2: ");
    scanf("%s", hobby2);

    printf("Enter Hobby 3: ");
    scanf("%s", hobby3);
	
    for (int i = 0; hobby1[i] != '\0'; i++) {
        hobby1[i] = toupper(hobby1[i]);
    }

    for (int i = 0; hobby2[i] != '\0'; i++) {
        hobby2[i] = toupper(hobby2[i]);
    }

    for (int i = 0; hobby3[i] != '\0'; i++) {
        hobby3[i] = toupper(hobby3[i]);
    }

    printf("%s %s %s", hobby1, hobby2, hobby3);

    return 0;
}
