// Nama: Agus Pranata Marpaung
// NIM: 13323033
// Kelas: 31TK2
#include <stdio.h>
#include <ctype.h>

int main()
{
   char 
   hiddenmessage[] ="I'm Happy";
   hiddenmessage[0] = 'H';
    hiddenmessage[1] = 'e';
     hiddenmessage[2] = 'l';
      hiddenmessage[3] = 'p';
       hiddenmessage[4] = ' ';
        hiddenmessage[5] = 'm';
         hiddenmessage[6] = 'e';
          hiddenmessage[7] = ' ';
           hiddenmessage[8] = '!';
   printf(" I'm Happy \n" );
   printf("%s",hiddenmessage);
return 0;
}
