#include<stdio.h>

int main(){
    int i = 16;
    do{
        printf("%d ", i);
        i++;
    } while(i<=15);

}