#include <stdio.h>

int main() {
    for (int i = 1; i <= 15; i++) {
        printf("%d ", i);
    }

    return 0; 
}
