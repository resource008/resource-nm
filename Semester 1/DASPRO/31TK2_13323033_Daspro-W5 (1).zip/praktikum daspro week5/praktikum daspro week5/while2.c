#include<stdio.h>

int main(){
    int i = 1;
    while(i<=15){
        printf("%d ", i);
        i+=5;
    }
}