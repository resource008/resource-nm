#include <stdio.h>

int main() {
    for (int i = 15; i>=1; i--) {
        printf("%d ", i);
    }

    return 0;
}