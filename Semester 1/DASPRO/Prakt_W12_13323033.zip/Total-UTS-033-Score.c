#include <stdio.h>

int main() {
    int i;
    double uts[8], total = 0.0;

    for(i = 0; i < 8; i++) {
        printf("Masukkan nilai UTS %d: ", i+1);
        scanf("%lf", &uts[i]);

        total += uts[i];
    }
    double average = total / 8;
    printf("Rata-rata nilai UTS adalah %.2lf\n", average);

    return 0;
}