#include <stdio.h>
int main(){
	FILE *fp; //deklarasikan sebuah variable 'fp' dengan tipe data FILE *
	if((fp = fopen("readme.txt", "r")) == NULL) {
		printf("Error reading file!");
	}
	else{
		puts("Succesful opening file..."); //fungsi 'puts' sama dengan 'print' dengan tambahan '\n'
	
	}
	fclose(fp); //setelah digunakan, fp harus ditutup agar tidak menumpuk di memori
	return 0;
}