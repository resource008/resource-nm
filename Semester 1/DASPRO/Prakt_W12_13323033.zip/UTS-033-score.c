#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char *filename = "nilai.txt";
    FILE *f;
    char c;
    int i;
    
    for (i = 0; i < 8; i++) {
        if ((f = fopen(filename, "a")) == NULL) {
            puts("File cannot be opened!");
            exit(1);
        } else {
            printf("Masukkan pesan bebas ke-%d: ", i + 1);
            while ((c = getchar()) != '\n' && c != EOF) {
                putc(c, f);
            }
            putc('\n', f);
        }
        fclose(f);
    }

    return 0;
}
