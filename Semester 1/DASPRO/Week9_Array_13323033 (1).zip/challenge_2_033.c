/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Challenge 1
Tanggal     : 30/10/2023
*/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int baris = 2;
    int kolom = 2;
    int i, j;

    int** array1 = (int**)malloc(baris * sizeof(int*));
    int** array2 = (int**)malloc(baris * sizeof(int*));
    int** hasil = (int**)malloc(baris * sizeof(int*));

    for(i = 0; i < baris; i++) {
        array1[i] = (int*)malloc(kolom * sizeof(int));
        array2[i] = (int*)malloc(kolom * sizeof(int));
        hasil[i] = (int*)malloc(kolom * sizeof(int));
    }

    for(i = 0; i < baris; i++) {
        for(j = 0; j < kolom; j++) {
            array1[i][j] = i + j;
            array2[i][j] = i - j;
        }
    }

    for(i = 0; i < baris; i++) {
        for(j = 0; j < kolom; j++) {
            hasil[i][j] = array1[i][j] + array2[i][j];
        }
    }

    printf("Hasil penjumlahan array: \n");
    for(i = 0; i < baris; i++) {
        for(j = 0; j < kolom; j++) {
            printf("%d ", hasil[i][j]);
        }
        printf("\n");
    }

    for(i = 0; i < baris; i++) {
        free(array1[i]);
        free(array2[i]);
        free(hasil[i]);
    }

    free(array1);
    free(array2);
    free(hasil);

    return 0;
}
