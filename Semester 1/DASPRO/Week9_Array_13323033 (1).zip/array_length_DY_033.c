/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 3
Tanggal     : 27/10/2023
*/

//File Name: contigous_memory.c
/*Program yang menunjukkan bagaimana elemen suatu array disimpan pada memori yang berdekatan*/
#include <stdio.h>
#include <stdio.h>
int main()
{
    //Kamus
    int length;
    int a[5]; //Deklarasi array bertipe integer terdiri dari 5 elemen

    printf("Size of array (byte) = %d\n", sizeof(a));
    printf("Size of integer (byte) = %d\n", sizeof(int));

    length = sizeof(a) / sizeof(int); //hitung panjang array
    printf("Array length = %d\n", length);

    system("PAUSE");
    return 0;
}