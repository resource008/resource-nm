/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Challenge 1
Tanggal     : 30/10/2023
*/

#include <stdio.h>

int main() {
    int array1[2][2] = {{1, 2}, {3, 4}};
    int array2[2][2] = {{5, 6}, {7, 8}};
    int hasil[2][2];
    int i, j;
    
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 2; j++) {
            hasil[i][j] = array1[i][j] + array2[i][j];
        }
    }

    printf("Hasil penjumlahan array: \n");
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 2; j++) {
            printf("%d ", hasil[i][j]);
        }
        printf("\n");
    }

    return 0;
}
