/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 2
Tanggal     : 27/10/2023
*/

//File Name: Single_dimensional_array.c
/*Program yang membuat array satu dimensi*/
#include <stdio.h>
#include <stdlib.h>
int main()
{
    //Kamus
    int i; //Variabel untuk iterasi
    int a[10]; //deklarasi array bertipe integer dan terdiri dari 10 elemen

    //Set the elemts of array to i+10
    for(i=0; i<10; i++)
        a[i] = i+10;

    //Print the elemets of array
    for(i=0; i<10; i++)
        printf("%d\n", a[i]);

    system("PAUSE");
    return 0;
}
