/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 5
Tanggal     : 27/10/2023
*/

//File Name: single_dimensional_array_dynamic_DY_NIM.c
/*Program yang membuat array satu dimensi dengan alokasi dinamis*/
#include <stdio.h>

int main() {
    // Deklarasi variabel untuk elemen vektor i dan j
    double i1, i2, i3, j1, j2, j3;

    // Meminta pengguna memasukkan nilai-nilai elemen vektor i
    printf("Masukkan nilai i1: ");
    scanf("%lf", &i1);
    printf("Masukkan nilai i2: ");
    scanf("%lf", &i2);
    printf("Masukkan nilai i3: ");
    scanf("%lf", &i3);

    // Meminta pengguna memasukkan nilai-nilai elemen vektor j
    printf("Masukkan nilai j1: ");
    scanf("%lf", &j1);
    printf("Masukkan nilai j2: ");
    scanf("%lf", &j2);
    printf("Masukkan nilai j3: ");
    scanf("%lf", &j3);

    // Menghitung hasil perkalian vektor
    double s = i1 * j1 + i2 * j2 + i3 * j3;

    // Menampilkan hasil perkalian vektor
    printf("Hasil perkalian vektor i x vektor j = %.2lf\n", s);

    return 0;
}
