/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 1
Tanggal     : 27/10/2023
*/

//File Name: contigous_memory.c
/*Program yang menunjukkan bagaimana elemen suatu array disimpan pada memori yang berdekatan*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    //kamus
    //Jika arr[0] disimpan pada alamat x, maka arr[1] disimpan pada alamat x + sizeof(int)
    //Jika arr[2] disimpan pada alamat x + sizeof(int) +sizeof(int)
    //Demikian seterusnya.
    int arr[5], i;
    printf("Size of integer in this compiler is %u", sizeof(int));
    for(i=0; i<5; i++);
    //The use of '&' before a variabe name, yields
    //Address of variable
    printf("Address arr[%d] is %u\n", i, &arr[i]); //%u untuk unsigned integer
    system("PAUSE");
    return 0;
}