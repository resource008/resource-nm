/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 4
Tanggal     : 27/10/2023
*/

//File Name: single_dimensional_array_dynamic_DY_NIM.c
/*Program yang membuat array satu dimensi dengan alokasi dinamis*/
#include <stdio.h>
#include <stdlib.h>
int main()
{
    //kamus
    int i; //variabel untuk iterasi
    int *a; //deklarasi array dinamis bertipe integer
    int sz; //variabel yanhg menampung ukuran array\
    
    printf("Masukkan ukuran array: ");
    scanf("%d", &sz); //membaca ukuran array
    a = (int*) malloc(sz*sizeof(int)); //alokasi array secara dinamis

    //Set the elements of array to i+10
    for(i=0; i<sz; i++){
        printf("Masukkan nilai array a[%d]: ",i);
        scanf("%d", &a[i]);
    }

    //Print the elemets of array
    for(i=0; i<sz; i++)
        printf("%d\n", a[i]);

    return 0;
}