/*
Nama        : Agus Pranata Marpaung
NIM         : 13323033
Deskripsi   : Program 2
Tanggal     : 27/10/2023
*/

//File Name: single_dimensional_arrayIinput.c
/*Program yang membuat array satu dimensi dan menerima elemen array dari input user*/
int main()
{
    //Kamus
    int i;
    int a[10]; //Deklarasi array bertipe integer dan terdiri dari 10 elemen

    //Set the elemets of array to i+10
    for(i=0; i<10; i++){
        printf("Masukkan nilai array a[%d]: ", i);
        scanf("%d", &a[i]);
    //Print the elemets of array
    for(i=0; i<10; i++)
        printf("%d\n", a[i]);
        
    system("PAUSE");
    return 0;
    }
}