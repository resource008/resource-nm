document.addEventListener("DOMContentLoaded", function() {
    var image = document.querySelector(".content img");
    
    image.addEventListener("mouseover", function() {
        image.style.transform = "scale(1.1)";
    });

    image.addEventListener("mouseout", function() {
        image.style.transform = "scale(1)";
    });
});