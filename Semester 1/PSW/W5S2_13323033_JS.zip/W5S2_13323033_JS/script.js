var x = 10;
console.log("Hello Word");
console.log("isi variabel x adalah " +x);
