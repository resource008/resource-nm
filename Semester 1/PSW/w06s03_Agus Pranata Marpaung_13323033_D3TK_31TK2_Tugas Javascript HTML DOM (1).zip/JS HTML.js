window.onload = function() {
    
    var logo = document.querySelector('.logo img');
    logo.addEventListener('mouseover', function() {
      this.style.transform = 'rotate(360deg)';
    });
    logo.addEventListener('mouseout', function() {
      this.style.transform = 'rotate(0deg)';
    });
  
    
    var welcomeMessage = 'Selamat datang di halaman HTML5 dan CSS.';
    alert(welcomeMessage);
  }
  